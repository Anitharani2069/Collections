package com.cg.eis.exception;
import java.util.Scanner;
public class EmployeeValidation extends Exception
{
	public EmployeeValidation(String args) {
		System.out.println(args);
	}
	public static void main(String args[]) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first name of the Employee:");
		String firstName=sc.nextLine();
		System.out.println("Enter last name of the Employee:");
		String lastName=sc.nextLine();
		try {
			if(!firstName.equals("") && !lastName.equals(""))
			{
				System.out.println("first name of Employee");
				System.out.println(firstName);
				System.out.println("Last name of Employee");
				System.out.println(lastName);
			}
			else {
				throw new EmployeeValidation("first name and last name cant be empty");
			}
	} 
		catch(Exception e) 
		{
			e.printStackTrace();			}
		}
}