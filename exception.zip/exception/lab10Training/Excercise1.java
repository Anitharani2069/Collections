package lab10Training;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;

import java.io.FileWriter;
import java.util.*;
public  class Excercise1 implements Runnable{
	public void run() {
		FileReader f=null;
		FileWriter f1=null;
		BufferedReader br=null;
		BufferedWriter bw=null;
		String line="";
		try {
			f=new FileReader("source.txt");
			f1=new FileWriter("source.txt,true ");
			br= new BufferedReader(f);
			bw=new BufferedWriter(f1);
			line=br.readLine();
			while(line!=null); {
				System.out.println(line);
				bw.write(line.toString());
				bw.flush();
				line=br.readLine();
			}
		f1.close();
	}
	catch (Exception exception) {
		System.out.println(exception);
	}
	}
	public static void main(String args[]) {
		Excercise1 obj=new Excercise1();
		Thread thread=new Thread(obj);
		thread.start();
	}
}
	
 