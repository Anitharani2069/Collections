package lab10Training;

public class Excercise2 implements Runnable{
	int count=0;
	public void run() {
		while(true) {
			System.out.println("Timer ="+count+ " seconds");
			try {
				Thread.sleep(1000);
				count++;
				if(count==1) {
					System.out.println("\nTimer Reset\n");
					count=0;
				}
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			} 
		}
	}
	public static void main(String args[]) {
		Excercise2 obj=new Excercise2();
		Thread thread=new Thread(obj);
		thread.start();
	}

}
