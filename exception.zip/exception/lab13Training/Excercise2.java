package lab13Training;
import java.util.*;

import java.util.Scanner;
interface lambda {
	public String print(String s);
}
public class Excercise2 {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		String str=scan.next();
		lambda lam=(s)-> {
			StringBuilder builder=new StringBuilder();
			for(int i=0;i<str.length();i++) {
				builder=builder.append(str.charAt(i)).append(" ");
			}
			return builder.toString();
		};
		String r=lam.print(str);
		System.out.println(" " +r);
	}
}
