package lab13Training;
import java.util.Scanner;
import java.util.Comparator;
interface lambda1{
	public boolean print(String name,String pass);
}
public class Excercise3 {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		String name1=scan.next();
		System.out.println("Entered name "+name1);
		String pass1=scan.next();
		System.out.println("Entered password "+pass1);
		lambda1 l=(name,pass)->{if(name.equals(name1)&&pass.equals(pass1))
			return true;
		else
			return false;
		};
		boolean output=l.print("anitha", "414");
		System.out.println(output);
	}
}
