package lab13Training;
import java.util.function.Function;
public class Excercise5 {
public static void main(String args[]) {
	Excercise5 ch=new Excercise5() ;
	Function<Integer,Long>fun=ch::fact;
	long res=fun.apply(5);
	System.out.println(res);
}
public long fact(int num) {
	long factres=1;
	for(int i=1;i<=num;i++){
		factres=factres*i;
		}
	return factres;
	
}
}
