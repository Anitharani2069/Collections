package lab1Training;
import java.util.Scanner;
import java.lang.Math;
public class Excercise1 {
	public void caluclateSum(int number)
	{
		int sum=0;
		for(int i=0;i<=number;i++)
		{
			if(i%3==0 || i%5==0)
			{
				sum=sum+i;
			}
		}
			System.out.println(sum);
		}
		public static void main(String args[]) 
		{
			Scanner scanner=new Scanner(System.in);
			int n=scanner.nextInt();
			Excercise1 na=new Excercise1();
			na.caluclateSum(n);
		}
}
