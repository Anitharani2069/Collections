package lab1Training;
import java.util.Scanner;
public class Excercise2 {
	public void caluclateDifference(int n) 
	{
	int square,square1,add=0,difference=0,sum=0;
	for(int i=0;i<=n;i++) 
	{
		square=i*i;
		sum=sum+square;
		add=add+i;
		square1=add*add;
		difference=square1-sum;
	}
	System.out.println(difference);
	}
public static void main(String args[])
{
	Scanner scanner=new Scanner(System.in);
	int n=scanner.nextInt();
	Excercise2 squareDifference= new Excercise2();
	squareDifference.caluclateDifference(n);
}
}