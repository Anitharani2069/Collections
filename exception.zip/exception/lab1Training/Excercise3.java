package lab1Training;

import java.util.Scanner;

public class Excercise3 {
	public boolean checkNumber(int num)
	{
		while(num>0)
		{
			int value1=num%10;
			num=num/10;
			int value2=num%10;
			if(value1<value2)
			{
				return false;
			}
		}
		return true;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		Excercise3 in=new Excercise3();
		System.out.println(in.checkNumber(num));
	}

}
