package lab1Training;
import java.lang.Math;
import java.util.Scanner;
public class Excercise4 {
	public boolean checkNumber(int n)
	{
		int i=1,num = 0;
		while(i<10)
		{
			num=(int) Math.pow(2,i);
			if(num==n)
			{
				return true;
			}
			i++;
		}
		return false;
	}
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	int num=sc.nextInt();
	Excercise4 tp=new Excercise4();
	System.out.println(tp.checkNumber(num));
}
}
