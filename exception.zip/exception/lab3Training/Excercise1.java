package lab3Training;
import java.util.Scanner;
public class Excercise1 {
	public int getSecondSmallest(int n[]) {
		int number=n.length;
		int arr[]=new int[number];
		int temp=0;
	        for(int i = 0; i < number; i++)
	        	for(int j=i+1;j<number;j++)
	        {
	            if(n[i]>n[j])
	            {
	               temp=n[i];
	               n[i]=n[j];
	               n[j]=temp;
	            }
	        }
			return n[1];
		}
		
	
		public static void main(String args[]) 
		{
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter the no of array integers:");
			int n=scanner.nextInt();
			System.out.println("Enter the array Integers:");
			int arr[]=new int[n];
			for(int i=0;i<n;i++)
			{
				arr[i]=scanner.nextInt();
			}
			Excercise1 excercise=new Excercise1();
			System.out.println("The second smallest Integer:");
			System.out.println(excercise.getSecondSmallest(arr));	
	}
}

		
