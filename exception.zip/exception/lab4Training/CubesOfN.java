package lab4Training;
import java.util.Scanner;
public class CubesOfN {
	public int sumOfCube(int number)
	{
		int sum=0,cube;
		for(int i=1;i<=number;i++)
		{
			cube =i*i*i;
			sum =sum+cube;
		}
		return sum;
	}
	public static void main(String args[])
	{
		Scanner scan=new Scanner(System.in);
		int newNum=scan.nextInt();
		CubesOfN con=new CubesOfN();
		System.out.println(con.sumOfCube(newNum));
	}
}