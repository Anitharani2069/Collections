package lab5Training;
import java.util.Scanner;
public class Excercise2 {
	public static void fibWithoutRec(int number)
	{
		int num1=0,num2=1,num3= 0,i;
		System.out.println(num1+" "+num2);
		for(i=2;i<number;++i) {
			num3=num1+num2;
			System.out.println(" "+num3);
			num1=num2;
			num2=num3;
		}
	}
	public static void fibWithRec (int number)
	{
		int num1=0,num2=1,num3=0;
		if(number>0) {
			num3=num1+num2;
			num1=num2;
			num2=num3;
			System.out.println(" "+num3);
			fibWithRec(number-1);
		}
	}
	public static void main(String args[]) {
		int limit,choice;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the limit of fibannoci series");
		limit = sc.nextInt();
		System.out.println("Enter 1 to print the fibannoci using recursion\nEnter 2 to print fibannoci without recursion");
		choice=sc.nextInt();
		if(choice==1)
			fibWithRec(limit);
		else if(choice==2)
			fibWithoutRec(limit);
		else
			System.out.println("INVALID CHOICE");
	}
}
