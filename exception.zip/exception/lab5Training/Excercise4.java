package lab5Training;
import java.util.Scanner;
public class Excercise4 extends Exception
{
	public Excercise4(String args) {
		System.out.println(args);
	}
	public static void main(String args[]) 
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter first name of the Employee:");
		String firstName=scan.nextLine();
		System.out.println("Enter last name of the Employee:");
		String lastName=scan.nextLine();
		try {
			if(!firstName.equals("") && !lastName.equals(""))
			{
				System.out.println("first name of the Employee");
				System.out.println(firstName);
				System.out.println("Last name of Employee");
				System.out.println(lastName);
			}
			else {
				throw new Excercise4("first name and last name cant be empty");
			}
	} 
		catch(Exception exception) 
		{
			exception.printStackTrace();			}
		}
}
