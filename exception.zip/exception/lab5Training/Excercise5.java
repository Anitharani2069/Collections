package lab5Training;
import java.util.Scanner;
class Excercise5 extends Exception
{
public Excercise5(String args)
	{
		System.out.println(args);
	}
	public static void main(String args[]) 
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter your age:");
		int age =scan.nextInt();
		try{
			if (age>=15) {
				System.out.println("valid age");
			}
			else {
				throw new Excercise5("Invalid age");

			}
		}
		catch(Excercise5 exception) 
		{
			exception.printStackTrace();
		}
	}
}
	