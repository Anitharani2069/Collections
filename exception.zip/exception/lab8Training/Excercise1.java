package lab8Training;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Excercise1 {
	
	public static void main(String[] arg)
	{
		Scanner scan=new Scanner(System.in);
		String s=scan.nextLine();
		StringTokenizer stringT=new StringTokenizer (s);
		int sum=0;
		while(stringT.hasMoreTokens())
			
		{
			String str1=stringT.nextToken();
			sum=sum+Integer.parseInt(str1);
			
		}
		System.out.println(sum);
		
		
	}

}
