package lab8Training;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.*;

public class Excercise2 {
	public static void main(String[] arg)throws IOException
	{
		BufferedReader buffRead=new BufferedReader(new FileReader("source.txt"));
		int count=1;
		String str=buffRead.readLine();
		while(str!=null)
		{
			System.out.println(count+"."+str);
			str=buffRead.readLine();
			count++;
			
			
		}
		buffRead.close();
	}

}
