package lab8Training;

import java.util.Arrays;
import java.util.Scanner;

public class Excercise5 {
    static boolean order(String alph)
    {
        boolean flag=true;
        int n=alph.length();
        char c[]=new char[n];
        for(int i=0;i<n;i++)
            c[i]=alph.charAt(i);
            Arrays.sort(c);
for(int i=0;i<n;i++)
{
if(c[i]!=alph.charAt(i)){
    flag=false;
      break;
}
}
System.out.println("String is positive:"+flag);
return flag;
    }
public static void main(String args[])
{
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter the String");
    String str=scan.next();
    order(str);
    scan.close();
}
}
 