package lab8Training;
import java.text.ParseException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.util.*;

 

public class Excercise6 {
     
static void duration(LocalDate date)
{
    LocalDate dat=LocalDate.now();
    System.out.println("Today"+dat);
    Period diff=Period.between(date,dat);
    System.out.println("Duration is"+diff.getDays()+"days");
    System.out.println("Duration is"+diff.getYears()+"years");
    System.out.println("Duration is"+diff.getMonths()+"months");
}
public static void main(String args[]) throws ParseException
{
    System.out.println("Enter date in dd-MM-yyyy format");
    Scanner sc=new Scanner(System.in);
    try{
    String s=sc.next();
    DateTimeFormatter d=DateTimeFormatter.ofPattern("dd-MM-yyyy");
    LocalDate date=LocalDate.parse(s,d);
    duration(date);
    }
    catch(Exception e)
    {
        System.out.println(e);
    }
    sc.close();
}
}
 


