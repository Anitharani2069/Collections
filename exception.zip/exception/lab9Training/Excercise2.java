package lab9Training;
import java.util.*;

import java.util.Scanner;
class HelperClass 
{

	 public HashMap countCharacter(char[] ar) 
	 {
		 {
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		for(char c:ar)
		{
		if(hm.containsKey(c))	{
			hm.put(c,hm.get(c)+1);
		}
		else {
			hm.put(c,1);
			}
		}
		return hm;
		}
	 }
}
	 public class Excercise2 
	 {
	public static void main(String args[])
	{
		HelperClass hc=new HelperClass();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the characters:");
		String str=sc.next();
		char[] hr=str.toCharArray();
		HashMap hss=hc.countCharacter(hr);
		Excercise2 e2=new Excercise2();
		System.out.println(hss);
	}
}