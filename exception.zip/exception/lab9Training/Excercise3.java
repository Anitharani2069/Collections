package lab9Training;

import java.util.*;

import java.util.Scanner;
public class Excercise3 {
	public void getSquares(int arr[])
	{
		int len=arr.length;
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		for(int i=0;i<len;i++) {
			hm.put(arr[i],arr[i]*arr[i]);
		}
		System.out.println(hm);
	}
	public static void main(String args[]) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the key index:");
		int n=sc.nextInt();
		System.out.println("enter the key values:");
		int arr[]=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		Excercise3 gs=new Excercise3();
		gs.getSquares(arr);
	}
	
}
