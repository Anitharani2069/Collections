package lab9Training;
import java.util.*;
public class Exercise1 {
	List<Integer> getValues(HashMap<Integer,String> h) 
	{
		Set<Integer> s=h.keySet();
		List<Integer> l=new ArrayList<Integer>(s);
		Collections.sort(l);
		return l;
	}
	public static void main(String args[]) {
		HashMap<Integer,String> h=new HashMap<Integer,String>();  //hashMap Creation
		h.put(1,"hello");        //adding values to list
		h.put(15,"anitha");
		h.put(11, "Happy");
		Exercise1 hm=new Exercise1();
		List<Integer> l1=hm.getValues(h);
		System.out.println(l1);
		System.out.println(h);
	}
}
